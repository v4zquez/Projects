﻿namespace AplicaciónInvernadero
{
    partial class Panel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Panel));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label39 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.lblSegundos = new System.Windows.Forms.Label();
            this.lblIntesidadLum = new System.Windows.Forms.Label();
            this.grpBxHorHum = new System.Windows.Forms.GroupBox();
            this.txtbxHH_OFF = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtbxHH_ON = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.grpBxRangoHum = new System.Windows.Forms.GroupBox();
            this.txtbxRH_OFF = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtbxRH_ON = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.grpBxHorTem = new System.Windows.Forms.GroupBox();
            this.txtbxHT_OFF = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtbxHT_ON = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.grpBxHorLum = new System.Windows.Forms.GroupBox();
            this.txtbxHL_OFF = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtbxHL_ON = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.grpBxRangoTem = new System.Windows.Forms.GroupBox();
            this.txtbxRT_OFF = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtbxRT_ON = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.grpBxRangoLum = new System.Windows.Forms.GroupBox();
            this.pgssBIntdLumA = new System.Windows.Forms.ProgressBar();
            this.pgssBIntdLumE = new System.Windows.Forms.ProgressBar();
            this.label2 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lblHora = new System.Windows.Forms.Label();
            this.lblHumedad = new System.Windows.Forms.Label();
            this.lblTemperatura = new System.Windows.Forms.Label();
            this.btnOFFAgua = new System.Windows.Forms.Button();
            this.btnONAgua = new System.Windows.Forms.Button();
            this.ptrBxHum = new System.Windows.Forms.PictureBox();
            this.btnOFFVentilador = new System.Windows.Forms.Button();
            this.btnONVentilador = new System.Windows.Forms.Button();
            this.ptrBxTem = new System.Windows.Forms.PictureBox();
            this.btnOFFBombillo = new System.Windows.Forms.Button();
            this.btnONBombillo = new System.Windows.Forms.Button();
            this.pgssBIntdLum = new System.Windows.Forms.ProgressBar();
            this.label1 = new System.Windows.Forms.Label();
            this.ptrBxIntdLum = new System.Windows.Forms.PictureBox();
            this.ptrBxParametros = new System.Windows.Forms.PictureBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.lblDatosGuardados = new System.Windows.Forms.Label();
            this.btnGuardar = new System.Windows.Forms.Button();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.label36 = new System.Windows.Forms.Label();
            this.chBxHR = new System.Windows.Forms.CheckBox();
            this.label37 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.MinApagHum = new System.Windows.Forms.ComboBox();
            this.label19 = new System.Windows.Forms.Label();
            this.MinEncdHum = new System.Windows.Forms.ComboBox();
            this.HoraApagHum = new System.Windows.Forms.ComboBox();
            this.HoraEncdHum = new System.Windows.Forms.ComboBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.label34 = new System.Windows.Forms.Label();
            this.chBxHV = new System.Windows.Forms.CheckBox();
            this.label35 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.MinApagTem = new System.Windows.Forms.ComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.MinEncdTem = new System.Windows.Forms.ComboBox();
            this.HoraApagTem = new System.Windows.Forms.ComboBox();
            this.HoraEncdTem = new System.Windows.Forms.ComboBox();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.RangoApagHum = new System.Windows.Forms.ComboBox();
            this.label28 = new System.Windows.Forms.Label();
            this.RangoEncdHum = new System.Windows.Forms.ComboBox();
            this.label29 = new System.Windows.Forms.Label();
            this.chBxRR = new System.Windows.Forms.CheckBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.label33 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.MinApagLum = new System.Windows.Forms.ComboBox();
            this.chBxHB = new System.Windows.Forms.CheckBox();
            this.MinEncdLum = new System.Windows.Forms.ComboBox();
            this.HoraApagLum = new System.Windows.Forms.ComboBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.HoraEncdLum = new System.Windows.Forms.ComboBox();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.RangoApagTem = new System.Windows.Forms.ComboBox();
            this.label27 = new System.Windows.Forms.Label();
            this.RangoEncdTem = new System.Windows.Forms.ComboBox();
            this.label26 = new System.Windows.Forms.Label();
            this.chBxRV = new System.Windows.Forms.CheckBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.RangoEncdLum = new System.Windows.Forms.ComboBox();
            this.label31 = new System.Windows.Forms.Label();
            this.chBxRB = new System.Windows.Forms.CheckBox();
            this.label25 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.lblFecha = new System.Windows.Forms.Label();
            this.Temporizador = new System.Windows.Forms.Timer(this.components);
            this.lblConfigHora = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.grpBxHorHum.SuspendLayout();
            this.grpBxRangoHum.SuspendLayout();
            this.grpBxHorTem.SuspendLayout();
            this.grpBxHorLum.SuspendLayout();
            this.grpBxRangoTem.SuspendLayout();
            this.grpBxRangoLum.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ptrBxHum)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptrBxTem)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptrBxIntdLum)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptrBxParametros)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(0, 36);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(714, 446);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.label39);
            this.tabPage1.Controls.Add(this.label38);
            this.tabPage1.Controls.Add(this.lblSegundos);
            this.tabPage1.Controls.Add(this.lblIntesidadLum);
            this.tabPage1.Controls.Add(this.grpBxHorHum);
            this.tabPage1.Controls.Add(this.grpBxRangoHum);
            this.tabPage1.Controls.Add(this.grpBxHorTem);
            this.tabPage1.Controls.Add(this.grpBxHorLum);
            this.tabPage1.Controls.Add(this.grpBxRangoTem);
            this.tabPage1.Controls.Add(this.grpBxRangoLum);
            this.tabPage1.Controls.Add(this.lblHora);
            this.tabPage1.Controls.Add(this.lblHumedad);
            this.tabPage1.Controls.Add(this.lblTemperatura);
            this.tabPage1.Controls.Add(this.btnOFFAgua);
            this.tabPage1.Controls.Add(this.btnONAgua);
            this.tabPage1.Controls.Add(this.ptrBxHum);
            this.tabPage1.Controls.Add(this.btnOFFVentilador);
            this.tabPage1.Controls.Add(this.btnONVentilador);
            this.tabPage1.Controls.Add(this.ptrBxTem);
            this.tabPage1.Controls.Add(this.btnOFFBombillo);
            this.tabPage1.Controls.Add(this.btnONBombillo);
            this.tabPage1.Controls.Add(this.pgssBIntdLum);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.ptrBxIntdLum);
            this.tabPage1.Controls.Add(this.ptrBxParametros);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(706, 420);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Panel de control";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // label39
            // 
            this.label39.BackColor = System.Drawing.SystemColors.ControlDark;
            this.label39.Font = new System.Drawing.Font("Impact", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(197, 106);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(52, 58);
            this.label39.TabIndex = 29;
            this.label39.Text = "%";
            // 
            // label38
            // 
            this.label38.BackColor = System.Drawing.SystemColors.ControlDark;
            this.label38.Font = new System.Drawing.Font("Impact", 33F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(149, 44);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(100, 62);
            this.label38.TabIndex = 28;
            this.label38.Text = "° C";
            // 
            // lblSegundos
            // 
            this.lblSegundos.BackColor = System.Drawing.SystemColors.ControlDark;
            this.lblSegundos.Font = new System.Drawing.Font("Impact", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSegundos.Location = new System.Drawing.Point(40, 136);
            this.lblSegundos.Name = "lblSegundos";
            this.lblSegundos.Size = new System.Drawing.Size(112, 28);
            this.lblSegundos.TabIndex = 27;
            this.lblSegundos.Text = "  00";
            this.lblSegundos.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblIntesidadLum
            // 
            this.lblIntesidadLum.AutoSize = true;
            this.lblIntesidadLum.Location = new System.Drawing.Point(182, 279);
            this.lblIntesidadLum.Name = "lblIntesidadLum";
            this.lblIntesidadLum.Size = new System.Drawing.Size(19, 13);
            this.lblIntesidadLum.TabIndex = 26;
            this.lblIntesidadLum.Text = "---";
            // 
            // grpBxHorHum
            // 
            this.grpBxHorHum.Controls.Add(this.txtbxHH_OFF);
            this.grpBxHorHum.Controls.Add(this.label8);
            this.grpBxHorHum.Controls.Add(this.txtbxHH_ON);
            this.grpBxHorHum.Controls.Add(this.label9);
            this.grpBxHorHum.Location = new System.Drawing.Point(566, 247);
            this.grpBxHorHum.Name = "grpBxHorHum";
            this.grpBxHorHum.Size = new System.Drawing.Size(134, 81);
            this.grpBxHorHum.TabIndex = 24;
            this.grpBxHorHum.TabStop = false;
            this.grpBxHorHum.Text = "Horarios";
            // 
            // txtbxHH_OFF
            // 
            this.txtbxHH_OFF.Enabled = false;
            this.txtbxHH_OFF.Location = new System.Drawing.Point(73, 46);
            this.txtbxHH_OFF.Name = "txtbxHH_OFF";
            this.txtbxHH_OFF.Size = new System.Drawing.Size(53, 20);
            this.txtbxHH_OFF.TabIndex = 33;
            this.txtbxHH_OFF.Text = "00:00";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 50);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(30, 13);
            this.label8.TabIndex = 20;
            this.label8.Text = "OFF";
            // 
            // txtbxHH_ON
            // 
            this.txtbxHH_ON.Enabled = false;
            this.txtbxHH_ON.Location = new System.Drawing.Point(73, 19);
            this.txtbxHH_ON.Name = "txtbxHH_ON";
            this.txtbxHH_ON.Size = new System.Drawing.Size(53, 20);
            this.txtbxHH_ON.TabIndex = 32;
            this.txtbxHH_ON.Text = "00:00";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(6, 27);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(25, 13);
            this.label9.TabIndex = 2;
            this.label9.Text = "ON";
            // 
            // grpBxRangoHum
            // 
            this.grpBxRangoHum.Controls.Add(this.txtbxRH_OFF);
            this.grpBxRangoHum.Controls.Add(this.label7);
            this.grpBxRangoHum.Controls.Add(this.txtbxRH_ON);
            this.grpBxRangoHum.Controls.Add(this.label4);
            this.grpBxRangoHum.Location = new System.Drawing.Point(566, 159);
            this.grpBxRangoHum.Name = "grpBxRangoHum";
            this.grpBxRangoHum.Size = new System.Drawing.Size(134, 81);
            this.grpBxRangoHum.TabIndex = 17;
            this.grpBxRangoHum.TabStop = false;
            this.grpBxRangoHum.Text = "Rango (%)";
            // 
            // txtbxRH_OFF
            // 
            this.txtbxRH_OFF.Enabled = false;
            this.txtbxRH_OFF.Location = new System.Drawing.Point(73, 47);
            this.txtbxRH_OFF.Name = "txtbxRH_OFF";
            this.txtbxRH_OFF.Size = new System.Drawing.Size(53, 20);
            this.txtbxRH_OFF.TabIndex = 27;
            this.txtbxRH_OFF.Text = "0";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 50);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(30, 13);
            this.label7.TabIndex = 20;
            this.label7.Text = "OFF";
            // 
            // txtbxRH_ON
            // 
            this.txtbxRH_ON.Enabled = false;
            this.txtbxRH_ON.Location = new System.Drawing.Point(73, 20);
            this.txtbxRH_ON.Name = "txtbxRH_ON";
            this.txtbxRH_ON.Size = new System.Drawing.Size(53, 20);
            this.txtbxRH_ON.TabIndex = 26;
            this.txtbxRH_ON.Text = "0";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 27);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(25, 13);
            this.label4.TabIndex = 2;
            this.label4.Text = "ON";
            // 
            // grpBxHorTem
            // 
            this.grpBxHorTem.Controls.Add(this.txtbxHT_OFF);
            this.grpBxHorTem.Controls.Add(this.label10);
            this.grpBxHorTem.Controls.Add(this.txtbxHT_ON);
            this.grpBxHorTem.Controls.Add(this.label11);
            this.grpBxHorTem.Location = new System.Drawing.Point(427, 247);
            this.grpBxHorTem.Name = "grpBxHorTem";
            this.grpBxHorTem.Size = new System.Drawing.Size(133, 81);
            this.grpBxHorTem.TabIndex = 23;
            this.grpBxHorTem.TabStop = false;
            this.grpBxHorTem.Text = "Horarios";
            // 
            // txtbxHT_OFF
            // 
            this.txtbxHT_OFF.Enabled = false;
            this.txtbxHT_OFF.Location = new System.Drawing.Point(73, 46);
            this.txtbxHT_OFF.Name = "txtbxHT_OFF";
            this.txtbxHT_OFF.Size = new System.Drawing.Size(53, 20);
            this.txtbxHT_OFF.TabIndex = 31;
            this.txtbxHT_OFF.Text = "00:00";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(6, 50);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(30, 13);
            this.label10.TabIndex = 19;
            this.label10.Text = "OFF";
            // 
            // txtbxHT_ON
            // 
            this.txtbxHT_ON.Enabled = false;
            this.txtbxHT_ON.Location = new System.Drawing.Point(73, 19);
            this.txtbxHT_ON.Name = "txtbxHT_ON";
            this.txtbxHT_ON.Size = new System.Drawing.Size(53, 20);
            this.txtbxHT_ON.TabIndex = 30;
            this.txtbxHT_ON.Text = "00:00";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(6, 27);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(25, 13);
            this.label11.TabIndex = 1;
            this.label11.Text = "ON";
            // 
            // grpBxHorLum
            // 
            this.grpBxHorLum.Controls.Add(this.txtbxHL_OFF);
            this.grpBxHorLum.Controls.Add(this.label12);
            this.grpBxHorLum.Controls.Add(this.txtbxHL_ON);
            this.grpBxHorLum.Controls.Add(this.label13);
            this.grpBxHorLum.Location = new System.Drawing.Point(291, 247);
            this.grpBxHorLum.Name = "grpBxHorLum";
            this.grpBxHorLum.Size = new System.Drawing.Size(130, 81);
            this.grpBxHorLum.TabIndex = 22;
            this.grpBxHorLum.TabStop = false;
            this.grpBxHorLum.Text = "Horarios";
            // 
            // txtbxHL_OFF
            // 
            this.txtbxHL_OFF.Enabled = false;
            this.txtbxHL_OFF.Location = new System.Drawing.Point(71, 46);
            this.txtbxHL_OFF.Name = "txtbxHL_OFF";
            this.txtbxHL_OFF.Size = new System.Drawing.Size(53, 20);
            this.txtbxHL_OFF.TabIndex = 29;
            this.txtbxHL_OFF.Text = "00:00";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(6, 50);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(30, 13);
            this.label12.TabIndex = 21;
            this.label12.Text = "OFF";
            // 
            // txtbxHL_ON
            // 
            this.txtbxHL_ON.Enabled = false;
            this.txtbxHL_ON.Location = new System.Drawing.Point(71, 19);
            this.txtbxHL_ON.Name = "txtbxHL_ON";
            this.txtbxHL_ON.Size = new System.Drawing.Size(53, 20);
            this.txtbxHL_ON.TabIndex = 28;
            this.txtbxHL_ON.Text = "00:00";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(6, 27);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(25, 13);
            this.label13.TabIndex = 20;
            this.label13.Text = "ON";
            // 
            // grpBxRangoTem
            // 
            this.grpBxRangoTem.Controls.Add(this.txtbxRT_OFF);
            this.grpBxRangoTem.Controls.Add(this.label6);
            this.grpBxRangoTem.Controls.Add(this.txtbxRT_ON);
            this.grpBxRangoTem.Controls.Add(this.label3);
            this.grpBxRangoTem.Location = new System.Drawing.Point(427, 159);
            this.grpBxRangoTem.Name = "grpBxRangoTem";
            this.grpBxRangoTem.Size = new System.Drawing.Size(133, 81);
            this.grpBxRangoTem.TabIndex = 16;
            this.grpBxRangoTem.TabStop = false;
            this.grpBxRangoTem.Text = "Rango (°C)";
            // 
            // txtbxRT_OFF
            // 
            this.txtbxRT_OFF.Enabled = false;
            this.txtbxRT_OFF.Location = new System.Drawing.Point(73, 46);
            this.txtbxRT_OFF.Name = "txtbxRT_OFF";
            this.txtbxRT_OFF.Size = new System.Drawing.Size(53, 20);
            this.txtbxRT_OFF.TabIndex = 25;
            this.txtbxRT_OFF.Text = "0";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 50);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(30, 13);
            this.label6.TabIndex = 19;
            this.label6.Text = "OFF";
            // 
            // txtbxRT_ON
            // 
            this.txtbxRT_ON.Enabled = false;
            this.txtbxRT_ON.Location = new System.Drawing.Point(73, 19);
            this.txtbxRT_ON.Name = "txtbxRT_ON";
            this.txtbxRT_ON.Size = new System.Drawing.Size(53, 20);
            this.txtbxRT_ON.TabIndex = 24;
            this.txtbxRT_ON.Text = "0";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 27);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(25, 13);
            this.label3.TabIndex = 1;
            this.label3.Text = "ON";
            // 
            // grpBxRangoLum
            // 
            this.grpBxRangoLum.Controls.Add(this.pgssBIntdLumA);
            this.grpBxRangoLum.Controls.Add(this.pgssBIntdLumE);
            this.grpBxRangoLum.Controls.Add(this.label2);
            this.grpBxRangoLum.Controls.Add(this.label5);
            this.grpBxRangoLum.Location = new System.Drawing.Point(291, 159);
            this.grpBxRangoLum.Name = "grpBxRangoLum";
            this.grpBxRangoLum.Size = new System.Drawing.Size(130, 81);
            this.grpBxRangoLum.TabIndex = 15;
            this.grpBxRangoLum.TabStop = false;
            this.grpBxRangoLum.Text = "Rango";
            // 
            // pgssBIntdLumA
            // 
            this.pgssBIntdLumA.Location = new System.Drawing.Point(73, 43);
            this.pgssBIntdLumA.Name = "pgssBIntdLumA";
            this.pgssBIntdLumA.Size = new System.Drawing.Size(45, 23);
            this.pgssBIntdLumA.TabIndex = 26;
            // 
            // pgssBIntdLumE
            // 
            this.pgssBIntdLumE.Location = new System.Drawing.Point(73, 16);
            this.pgssBIntdLumE.Name = "pgssBIntdLumE";
            this.pgssBIntdLumE.Size = new System.Drawing.Size(45, 23);
            this.pgssBIntdLumE.TabIndex = 25;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 50);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(30, 13);
            this.label2.TabIndex = 21;
            this.label2.Text = "OFF";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 27);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(25, 13);
            this.label5.TabIndex = 20;
            this.label5.Text = "ON";
            // 
            // lblHora
            // 
            this.lblHora.BackColor = System.Drawing.SystemColors.ControlDark;
            this.lblHora.Font = new System.Drawing.Font("Impact", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHora.Location = new System.Drawing.Point(40, 105);
            this.lblHora.Name = "lblHora";
            this.lblHora.Size = new System.Drawing.Size(112, 31);
            this.lblHora.TabIndex = 14;
            this.lblHora.Text = "20:00";
            this.lblHora.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblHumedad
            // 
            this.lblHumedad.BackColor = System.Drawing.SystemColors.ControlDark;
            this.lblHumedad.Font = new System.Drawing.Font("Impact", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHumedad.Location = new System.Drawing.Point(149, 106);
            this.lblHumedad.Name = "lblHumedad";
            this.lblHumedad.Size = new System.Drawing.Size(52, 58);
            this.lblHumedad.TabIndex = 13;
            this.lblHumedad.Text = " 0";
            // 
            // lblTemperatura
            // 
            this.lblTemperatura.BackColor = System.Drawing.SystemColors.ControlDark;
            this.lblTemperatura.Font = new System.Drawing.Font("Impact", 35.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTemperatura.Location = new System.Drawing.Point(40, 44);
            this.lblTemperatura.Name = "lblTemperatura";
            this.lblTemperatura.Size = new System.Drawing.Size(122, 62);
            this.lblTemperatura.TabIndex = 12;
            this.lblTemperatura.Tag = "  ";
            this.lblTemperatura.Text = "       0";
            // 
            // btnOFFAgua
            // 
            this.btnOFFAgua.Location = new System.Drawing.Point(634, 119);
            this.btnOFFAgua.Name = "btnOFFAgua";
            this.btnOFFAgua.Size = new System.Drawing.Size(66, 28);
            this.btnOFFAgua.TabIndex = 11;
            this.btnOFFAgua.Text = "OFF";
            this.btnOFFAgua.UseVisualStyleBackColor = true;
            this.btnOFFAgua.Click += new System.EventHandler(this.btnOFFAgua_Click);
            // 
            // btnONAgua
            // 
            this.btnONAgua.Location = new System.Drawing.Point(566, 119);
            this.btnONAgua.Name = "btnONAgua";
            this.btnONAgua.Size = new System.Drawing.Size(64, 28);
            this.btnONAgua.TabIndex = 10;
            this.btnONAgua.Text = "ON";
            this.btnONAgua.UseVisualStyleBackColor = true;
            this.btnONAgua.Click += new System.EventHandler(this.btnONAgua_Click);
            // 
            // ptrBxHum
            // 
            this.ptrBxHum.Image = global::AplicaciónInvernadero.Properties.Resources.no_water;
            this.ptrBxHum.Location = new System.Drawing.Point(566, 18);
            this.ptrBxHum.Name = "ptrBxHum";
            this.ptrBxHum.Size = new System.Drawing.Size(133, 95);
            this.ptrBxHum.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.ptrBxHum.TabIndex = 9;
            this.ptrBxHum.TabStop = false;
            // 
            // btnOFFVentilador
            // 
            this.btnOFFVentilador.Location = new System.Drawing.Point(494, 119);
            this.btnOFFVentilador.Name = "btnOFFVentilador";
            this.btnOFFVentilador.Size = new System.Drawing.Size(66, 28);
            this.btnOFFVentilador.TabIndex = 8;
            this.btnOFFVentilador.Text = "OFF";
            this.btnOFFVentilador.UseVisualStyleBackColor = true;
            this.btnOFFVentilador.Click += new System.EventHandler(this.btnOFFVentilador_Click);
            // 
            // btnONVentilador
            // 
            this.btnONVentilador.Location = new System.Drawing.Point(427, 119);
            this.btnONVentilador.Name = "btnONVentilador";
            this.btnONVentilador.Size = new System.Drawing.Size(64, 28);
            this.btnONVentilador.TabIndex = 7;
            this.btnONVentilador.Text = "ON";
            this.btnONVentilador.UseVisualStyleBackColor = true;
            this.btnONVentilador.Click += new System.EventHandler(this.btnONVentilador_Click);
            // 
            // ptrBxTem
            // 
            this.ptrBxTem.Image = global::AplicaciónInvernadero.Properties.Resources.wind_off;
            this.ptrBxTem.Location = new System.Drawing.Point(427, 18);
            this.ptrBxTem.Name = "ptrBxTem";
            this.ptrBxTem.Size = new System.Drawing.Size(133, 95);
            this.ptrBxTem.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.ptrBxTem.TabIndex = 6;
            this.ptrBxTem.TabStop = false;
            // 
            // btnOFFBombillo
            // 
            this.btnOFFBombillo.Location = new System.Drawing.Point(355, 119);
            this.btnOFFBombillo.Name = "btnOFFBombillo";
            this.btnOFFBombillo.Size = new System.Drawing.Size(66, 28);
            this.btnOFFBombillo.TabIndex = 5;
            this.btnOFFBombillo.Text = "OFF";
            this.btnOFFBombillo.UseVisualStyleBackColor = true;
            this.btnOFFBombillo.Click += new System.EventHandler(this.btnOFFBombillo_Click);
            // 
            // btnONBombillo
            // 
            this.btnONBombillo.Location = new System.Drawing.Point(288, 119);
            this.btnONBombillo.Name = "btnONBombillo";
            this.btnONBombillo.Size = new System.Drawing.Size(64, 28);
            this.btnONBombillo.TabIndex = 4;
            this.btnONBombillo.Text = "ON";
            this.btnONBombillo.UseVisualStyleBackColor = true;
            this.btnONBombillo.Click += new System.EventHandler(this.btnONBombillo_Click);
            // 
            // pgssBIntdLum
            // 
            this.pgssBIntdLum.Location = new System.Drawing.Point(19, 303);
            this.pgssBIntdLum.Name = "pgssBIntdLum";
            this.pgssBIntdLum.Size = new System.Drawing.Size(251, 23);
            this.pgssBIntdLum.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(57, 279);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(127, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Intensidad Luminosa:";
            // 
            // ptrBxIntdLum
            // 
            this.ptrBxIntdLum.BackColor = System.Drawing.Color.Transparent;
            this.ptrBxIntdLum.Image = global::AplicaciónInvernadero.Properties.Resources.OFF;
            this.ptrBxIntdLum.Location = new System.Drawing.Point(288, 18);
            this.ptrBxIntdLum.Name = "ptrBxIntdLum";
            this.ptrBxIntdLum.Size = new System.Drawing.Size(133, 95);
            this.ptrBxIntdLum.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.ptrBxIntdLum.TabIndex = 1;
            this.ptrBxIntdLum.TabStop = false;
            // 
            // ptrBxParametros
            // 
            this.ptrBxParametros.Image = ((System.Drawing.Image)(resources.GetObject("ptrBxParametros.Image")));
            this.ptrBxParametros.Location = new System.Drawing.Point(7, 16);
            this.ptrBxParametros.Name = "ptrBxParametros";
            this.ptrBxParametros.Size = new System.Drawing.Size(275, 247);
            this.ptrBxParametros.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ptrBxParametros.TabIndex = 0;
            this.ptrBxParametros.TabStop = false;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.lblDatosGuardados);
            this.tabPage2.Controls.Add(this.btnGuardar);
            this.tabPage2.Controls.Add(this.groupBox9);
            this.tabPage2.Controls.Add(this.groupBox7);
            this.tabPage2.Controls.Add(this.groupBox11);
            this.tabPage2.Controls.Add(this.groupBox10);
            this.tabPage2.Controls.Add(this.groupBox8);
            this.tabPage2.Controls.Add(this.groupBox12);
            this.tabPage2.Controls.Add(this.pictureBox3);
            this.tabPage2.Controls.Add(this.pictureBox4);
            this.tabPage2.Controls.Add(this.pictureBox5);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(706, 420);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Configuración";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // lblDatosGuardados
            // 
            this.lblDatosGuardados.AutoSize = true;
            this.lblDatosGuardados.ForeColor = System.Drawing.Color.Green;
            this.lblDatosGuardados.Location = new System.Drawing.Point(160, 376);
            this.lblDatosGuardados.Name = "lblDatosGuardados";
            this.lblDatosGuardados.Size = new System.Drawing.Size(19, 13);
            this.lblDatosGuardados.TabIndex = 45;
            this.lblDatosGuardados.Text = "---";
            // 
            // btnGuardar
            // 
            this.btnGuardar.Location = new System.Drawing.Point(266, 365);
            this.btnGuardar.Name = "btnGuardar";
            this.btnGuardar.Size = new System.Drawing.Size(167, 34);
            this.btnGuardar.TabIndex = 44;
            this.btnGuardar.Text = "Guardar Cambios";
            this.btnGuardar.UseVisualStyleBackColor = true;
            this.btnGuardar.Click += new System.EventHandler(this.btnGuardar_Click);
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.label36);
            this.groupBox9.Controls.Add(this.chBxHR);
            this.groupBox9.Controls.Add(this.label37);
            this.groupBox9.Controls.Add(this.label18);
            this.groupBox9.Controls.Add(this.MinApagHum);
            this.groupBox9.Controls.Add(this.label19);
            this.groupBox9.Controls.Add(this.MinEncdHum);
            this.groupBox9.Controls.Add(this.HoraApagHum);
            this.groupBox9.Controls.Add(this.HoraEncdHum);
            this.groupBox9.Location = new System.Drawing.Point(443, 236);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(167, 117);
            this.groupBox9.TabIndex = 43;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Horarios";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(95, 49);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(11, 13);
            this.label36.TabIndex = 70;
            this.label36.Text = ":";
            // 
            // chBxHR
            // 
            this.chBxHR.AutoSize = true;
            this.chBxHR.Location = new System.Drawing.Point(66, 85);
            this.chBxHR.Name = "chBxHR";
            this.chBxHR.Size = new System.Drawing.Size(66, 17);
            this.chBxHR.TabIndex = 37;
            this.chBxHR.Text = "Activar";
            this.chBxHR.UseVisualStyleBackColor = true;
            this.chBxHR.CheckedChanged += new System.EventHandler(this.chBxHR_CheckedChanged);
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(95, 23);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(11, 13);
            this.label37.TabIndex = 69;
            this.label37.Text = ":";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(6, 50);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(30, 13);
            this.label18.TabIndex = 21;
            this.label18.Text = "OFF";
            // 
            // MinApagHum
            // 
            this.MinApagHum.FormattingEnabled = true;
            this.MinApagHum.Location = new System.Drawing.Point(108, 45);
            this.MinApagHum.Name = "MinApagHum";
            this.MinApagHum.Size = new System.Drawing.Size(42, 21);
            this.MinApagHum.TabIndex = 68;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(6, 27);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(25, 13);
            this.label19.TabIndex = 20;
            this.label19.Text = "ON";
            // 
            // MinEncdHum
            // 
            this.MinEncdHum.FormattingEnabled = true;
            this.MinEncdHum.Location = new System.Drawing.Point(108, 19);
            this.MinEncdHum.Name = "MinEncdHum";
            this.MinEncdHum.Size = new System.Drawing.Size(42, 21);
            this.MinEncdHum.TabIndex = 67;
            // 
            // HoraApagHum
            // 
            this.HoraApagHum.FormattingEnabled = true;
            this.HoraApagHum.Location = new System.Drawing.Point(53, 45);
            this.HoraApagHum.Name = "HoraApagHum";
            this.HoraApagHum.Size = new System.Drawing.Size(42, 21);
            this.HoraApagHum.TabIndex = 66;
            // 
            // HoraEncdHum
            // 
            this.HoraEncdHum.FormattingEnabled = true;
            this.HoraEncdHum.Location = new System.Drawing.Point(53, 19);
            this.HoraEncdHum.Name = "HoraEncdHum";
            this.HoraEncdHum.Size = new System.Drawing.Size(42, 21);
            this.HoraEncdHum.TabIndex = 65;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.label34);
            this.groupBox7.Controls.Add(this.chBxHV);
            this.groupBox7.Controls.Add(this.label35);
            this.groupBox7.Controls.Add(this.label14);
            this.groupBox7.Controls.Add(this.MinApagTem);
            this.groupBox7.Controls.Add(this.label15);
            this.groupBox7.Controls.Add(this.MinEncdTem);
            this.groupBox7.Controls.Add(this.HoraApagTem);
            this.groupBox7.Controls.Add(this.HoraEncdTem);
            this.groupBox7.Location = new System.Drawing.Point(266, 236);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(167, 117);
            this.groupBox7.TabIndex = 41;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Horarios";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(98, 50);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(11, 13);
            this.label34.TabIndex = 64;
            this.label34.Text = ":";
            // 
            // chBxHV
            // 
            this.chBxHV.AutoSize = true;
            this.chBxHV.Location = new System.Drawing.Point(66, 85);
            this.chBxHV.Name = "chBxHV";
            this.chBxHV.Size = new System.Drawing.Size(66, 17);
            this.chBxHV.TabIndex = 37;
            this.chBxHV.Text = "Activar";
            this.chBxHV.UseVisualStyleBackColor = true;
            this.chBxHV.CheckedChanged += new System.EventHandler(this.chBxHV_CheckedChanged);
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(98, 24);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(11, 13);
            this.label35.TabIndex = 63;
            this.label35.Text = ":";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(6, 50);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(30, 13);
            this.label14.TabIndex = 21;
            this.label14.Text = "OFF";
            // 
            // MinApagTem
            // 
            this.MinApagTem.FormattingEnabled = true;
            this.MinApagTem.Location = new System.Drawing.Point(111, 46);
            this.MinApagTem.Name = "MinApagTem";
            this.MinApagTem.Size = new System.Drawing.Size(42, 21);
            this.MinApagTem.TabIndex = 62;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(6, 27);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(25, 13);
            this.label15.TabIndex = 20;
            this.label15.Text = "ON";
            // 
            // MinEncdTem
            // 
            this.MinEncdTem.FormattingEnabled = true;
            this.MinEncdTem.Location = new System.Drawing.Point(111, 20);
            this.MinEncdTem.Name = "MinEncdTem";
            this.MinEncdTem.Size = new System.Drawing.Size(42, 21);
            this.MinEncdTem.TabIndex = 61;
            // 
            // HoraApagTem
            // 
            this.HoraApagTem.FormattingEnabled = true;
            this.HoraApagTem.Location = new System.Drawing.Point(56, 46);
            this.HoraApagTem.Name = "HoraApagTem";
            this.HoraApagTem.Size = new System.Drawing.Size(42, 21);
            this.HoraApagTem.TabIndex = 60;
            // 
            // HoraEncdTem
            // 
            this.HoraEncdTem.FormattingEnabled = true;
            this.HoraEncdTem.Location = new System.Drawing.Point(56, 20);
            this.HoraEncdTem.Name = "HoraEncdTem";
            this.HoraEncdTem.Size = new System.Drawing.Size(42, 21);
            this.HoraEncdTem.TabIndex = 59;
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.RangoApagHum);
            this.groupBox11.Controls.Add(this.label28);
            this.groupBox11.Controls.Add(this.RangoEncdHum);
            this.groupBox11.Controls.Add(this.label29);
            this.groupBox11.Controls.Add(this.chBxRR);
            this.groupBox11.Controls.Add(this.label22);
            this.groupBox11.Controls.Add(this.label23);
            this.groupBox11.Location = new System.Drawing.Point(443, 107);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(167, 122);
            this.groupBox11.TabIndex = 42;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Rango";
            // 
            // RangoApagHum
            // 
            this.RangoApagHum.FormattingEnabled = true;
            this.RangoApagHum.Location = new System.Drawing.Point(67, 46);
            this.RangoApagHum.Name = "RangoApagHum";
            this.RangoApagHum.Size = new System.Drawing.Size(58, 21);
            this.RangoApagHum.TabIndex = 52;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(127, 52);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(16, 13);
            this.label28.TabIndex = 45;
            this.label28.Text = "%";
            // 
            // RangoEncdHum
            // 
            this.RangoEncdHum.FormattingEnabled = true;
            this.RangoEncdHum.Location = new System.Drawing.Point(67, 20);
            this.RangoEncdHum.Name = "RangoEncdHum";
            this.RangoEncdHum.Size = new System.Drawing.Size(58, 21);
            this.RangoEncdHum.TabIndex = 51;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(128, 25);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(16, 13);
            this.label29.TabIndex = 44;
            this.label29.Text = "%";
            // 
            // chBxRR
            // 
            this.chBxRR.AutoSize = true;
            this.chBxRR.Location = new System.Drawing.Point(66, 90);
            this.chBxRR.Name = "chBxRR";
            this.chBxRR.Size = new System.Drawing.Size(66, 17);
            this.chBxRR.TabIndex = 32;
            this.chBxRR.Text = "Activar";
            this.chBxRR.UseVisualStyleBackColor = true;
            this.chBxRR.CheckedChanged += new System.EventHandler(this.chBxRR_CheckedChanged);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(6, 50);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(30, 13);
            this.label22.TabIndex = 21;
            this.label22.Text = "OFF";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(6, 27);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(25, 13);
            this.label23.TabIndex = 20;
            this.label23.Text = "ON";
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.label33);
            this.groupBox10.Controls.Add(this.label32);
            this.groupBox10.Controls.Add(this.MinApagLum);
            this.groupBox10.Controls.Add(this.chBxHB);
            this.groupBox10.Controls.Add(this.MinEncdLum);
            this.groupBox10.Controls.Add(this.HoraApagLum);
            this.groupBox10.Controls.Add(this.label20);
            this.groupBox10.Controls.Add(this.label21);
            this.groupBox10.Controls.Add(this.HoraEncdLum);
            this.groupBox10.Location = new System.Drawing.Point(91, 236);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(167, 117);
            this.groupBox10.TabIndex = 28;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Horarios";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(102, 51);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(11, 13);
            this.label33.TabIndex = 58;
            this.label33.Text = ":";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(102, 25);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(11, 13);
            this.label32.TabIndex = 57;
            this.label32.Text = ":";
            // 
            // MinApagLum
            // 
            this.MinApagLum.FormattingEnabled = true;
            this.MinApagLum.Location = new System.Drawing.Point(115, 47);
            this.MinApagLum.Name = "MinApagLum";
            this.MinApagLum.Size = new System.Drawing.Size(42, 21);
            this.MinApagLum.TabIndex = 56;
            // 
            // chBxHB
            // 
            this.chBxHB.AutoSize = true;
            this.chBxHB.Location = new System.Drawing.Point(67, 85);
            this.chBxHB.Name = "chBxHB";
            this.chBxHB.Size = new System.Drawing.Size(66, 17);
            this.chBxHB.TabIndex = 37;
            this.chBxHB.Text = "Activar";
            this.chBxHB.UseVisualStyleBackColor = true;
            this.chBxHB.CheckedChanged += new System.EventHandler(this.chBxHB_CheckedChanged);
            // 
            // MinEncdLum
            // 
            this.MinEncdLum.FormattingEnabled = true;
            this.MinEncdLum.Location = new System.Drawing.Point(115, 21);
            this.MinEncdLum.Name = "MinEncdLum";
            this.MinEncdLum.Size = new System.Drawing.Size(42, 21);
            this.MinEncdLum.TabIndex = 55;
            // 
            // HoraApagLum
            // 
            this.HoraApagLum.FormattingEnabled = true;
            this.HoraApagLum.Location = new System.Drawing.Point(60, 47);
            this.HoraApagLum.Name = "HoraApagLum";
            this.HoraApagLum.Size = new System.Drawing.Size(42, 21);
            this.HoraApagLum.TabIndex = 54;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(6, 50);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(30, 13);
            this.label20.TabIndex = 21;
            this.label20.Text = "OFF";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(6, 27);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(25, 13);
            this.label21.TabIndex = 20;
            this.label21.Text = "ON";
            // 
            // HoraEncdLum
            // 
            this.HoraEncdLum.FormattingEnabled = true;
            this.HoraEncdLum.Location = new System.Drawing.Point(60, 21);
            this.HoraEncdLum.Name = "HoraEncdLum";
            this.HoraEncdLum.Size = new System.Drawing.Size(42, 21);
            this.HoraEncdLum.TabIndex = 53;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.RangoApagTem);
            this.groupBox8.Controls.Add(this.label27);
            this.groupBox8.Controls.Add(this.RangoEncdTem);
            this.groupBox8.Controls.Add(this.label26);
            this.groupBox8.Controls.Add(this.chBxRV);
            this.groupBox8.Controls.Add(this.label16);
            this.groupBox8.Controls.Add(this.label17);
            this.groupBox8.Location = new System.Drawing.Point(266, 107);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(167, 122);
            this.groupBox8.TabIndex = 40;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Rango";
            // 
            // RangoApagTem
            // 
            this.RangoApagTem.FormattingEnabled = true;
            this.RangoApagTem.Location = new System.Drawing.Point(61, 46);
            this.RangoApagTem.Name = "RangoApagTem";
            this.RangoApagTem.Size = new System.Drawing.Size(58, 21);
            this.RangoApagTem.TabIndex = 50;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(123, 50);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(24, 13);
            this.label27.TabIndex = 36;
            this.label27.Text = "° C";
            // 
            // RangoEncdTem
            // 
            this.RangoEncdTem.FormattingEnabled = true;
            this.RangoEncdTem.Location = new System.Drawing.Point(61, 20);
            this.RangoEncdTem.Name = "RangoEncdTem";
            this.RangoEncdTem.Size = new System.Drawing.Size(58, 21);
            this.RangoEncdTem.TabIndex = 49;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(124, 23);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(24, 13);
            this.label26.TabIndex = 35;
            this.label26.Text = "° C";
            // 
            // chBxRV
            // 
            this.chBxRV.AutoSize = true;
            this.chBxRV.Location = new System.Drawing.Point(65, 90);
            this.chBxRV.Name = "chBxRV";
            this.chBxRV.Size = new System.Drawing.Size(66, 17);
            this.chBxRV.TabIndex = 32;
            this.chBxRV.Text = "Activar";
            this.chBxRV.UseVisualStyleBackColor = true;
            this.chBxRV.CheckedChanged += new System.EventHandler(this.chBxRV_CheckedChanged);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(6, 50);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(30, 13);
            this.label16.TabIndex = 21;
            this.label16.Text = "OFF";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(6, 27);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(25, 13);
            this.label17.TabIndex = 20;
            this.label17.Text = "ON";
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.RangoEncdLum);
            this.groupBox12.Controls.Add(this.label31);
            this.groupBox12.Controls.Add(this.chBxRB);
            this.groupBox12.Controls.Add(this.label25);
            this.groupBox12.Location = new System.Drawing.Point(91, 107);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(167, 122);
            this.groupBox12.TabIndex = 25;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "Rango";
            // 
            // RangoEncdLum
            // 
            this.RangoEncdLum.FormattingEnabled = true;
            this.RangoEncdLum.Location = new System.Drawing.Point(72, 20);
            this.RangoEncdLum.Name = "RangoEncdLum";
            this.RangoEncdLum.Size = new System.Drawing.Size(58, 21);
            this.RangoEncdLum.TabIndex = 45;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(135, 25);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(16, 13);
            this.label31.TabIndex = 46;
            this.label31.Text = "%";
            // 
            // chBxRB
            // 
            this.chBxRB.AutoSize = true;
            this.chBxRB.Location = new System.Drawing.Point(65, 87);
            this.chBxRB.Name = "chBxRB";
            this.chBxRB.Size = new System.Drawing.Size(66, 17);
            this.chBxRB.TabIndex = 32;
            this.chBxRB.Text = "Activar";
            this.chBxRB.UseVisualStyleBackColor = true;
            this.chBxRB.CheckedChanged += new System.EventHandler(this.chBxRB_CheckedChanged);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(6, 27);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(25, 13);
            this.label25.TabIndex = 20;
            this.label25.Text = "ON";
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::AplicaciónInvernadero.Properties.Resources.water_on;
            this.pictureBox3.Location = new System.Drawing.Point(444, 13);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(166, 88);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 12;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::AplicaciónInvernadero.Properties.Resources.wind_on;
            this.pictureBox4.Location = new System.Drawing.Point(266, 13);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(167, 88);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 11;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox5.Image = global::AplicaciónInvernadero.Properties.Resources.ON;
            this.pictureBox5.Location = new System.Drawing.Point(91, 13);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(167, 88);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 10;
            this.pictureBox5.TabStop = false;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.dataGridView1);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(706, 420);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Historial";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // lblFecha
            // 
            this.lblFecha.AutoSize = true;
            this.lblFecha.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFecha.Location = new System.Drawing.Point(1, 6);
            this.lblFecha.Name = "lblFecha";
            this.lblFecha.Size = new System.Drawing.Size(27, 13);
            this.lblFecha.TabIndex = 1;
            this.lblFecha.Text = "-----";
            // 
            // Temporizador
            // 
            this.Temporizador.Enabled = true;
            this.Temporizador.Interval = 1000;
            this.Temporizador.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // lblConfigHora
            // 
            this.lblConfigHora.AutoSize = true;
            this.lblConfigHora.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblConfigHora.Location = new System.Drawing.Point(649, 9);
            this.lblConfigHora.Name = "lblConfigHora";
            this.lblConfigHora.Size = new System.Drawing.Size(31, 13);
            this.lblConfigHora.TabIndex = 46;
            this.lblConfigHora.Text = "------";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(20, 38);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(665, 359);
            this.dataGridView1.TabIndex = 0;
            // 
            // Panel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(714, 481);
            this.Controls.Add(this.lblConfigHora);
            this.Controls.Add(this.lblFecha);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Panel";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Vivero";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Panel_FormClosing);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Panel_FormClosed);
            this.Load += new System.EventHandler(this.Panel_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.grpBxHorHum.ResumeLayout(false);
            this.grpBxHorHum.PerformLayout();
            this.grpBxRangoHum.ResumeLayout(false);
            this.grpBxRangoHum.PerformLayout();
            this.grpBxHorTem.ResumeLayout(false);
            this.grpBxHorTem.PerformLayout();
            this.grpBxHorLum.ResumeLayout(false);
            this.grpBxHorLum.PerformLayout();
            this.grpBxRangoTem.ResumeLayout(false);
            this.grpBxRangoTem.PerformLayout();
            this.grpBxRangoLum.ResumeLayout(false);
            this.grpBxRangoLum.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ptrBxHum)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptrBxTem)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptrBxIntdLum)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptrBxParametros)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.tabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.PictureBox ptrBxParametros;
        private System.Windows.Forms.PictureBox ptrBxIntdLum;
        private System.Windows.Forms.Label lblFecha;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ProgressBar pgssBIntdLum;
        private System.Windows.Forms.Button btnOFFBombillo;
        private System.Windows.Forms.Button btnONBombillo;
        private System.Windows.Forms.Button btnOFFAgua;
        private System.Windows.Forms.Button btnONAgua;
        private System.Windows.Forms.PictureBox ptrBxHum;
        private System.Windows.Forms.Button btnOFFVentilador;
        private System.Windows.Forms.Button btnONVentilador;
        private System.Windows.Forms.PictureBox ptrBxTem;
        private System.Windows.Forms.Label lblTemperatura;
        private System.Windows.Forms.Label lblHora;
        private System.Windows.Forms.Label lblHumedad;
        private System.Windows.Forms.GroupBox grpBxRangoHum;
        private System.Windows.Forms.GroupBox grpBxRangoTem;
        private System.Windows.Forms.GroupBox grpBxRangoLum;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox grpBxHorHum;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.GroupBox grpBxHorTem;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.GroupBox grpBxHorLum;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtbxHH_OFF;
        private System.Windows.Forms.TextBox txtbxHH_ON;
        private System.Windows.Forms.TextBox txtbxRH_OFF;
        private System.Windows.Forms.TextBox txtbxRH_ON;
        private System.Windows.Forms.TextBox txtbxHT_OFF;
        private System.Windows.Forms.TextBox txtbxHT_ON;
        private System.Windows.Forms.TextBox txtbxHL_OFF;
        private System.Windows.Forms.TextBox txtbxHL_ON;
        private System.Windows.Forms.TextBox txtbxRT_OFF;
        private System.Windows.Forms.TextBox txtbxRT_ON;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.CheckBox chBxHB;
        private System.Windows.Forms.CheckBox chBxRB;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.CheckBox chBxHV;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.CheckBox chBxRV;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.CheckBox chBxHR;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.CheckBox chBxRR;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ProgressBar pgssBIntdLumA;
        private System.Windows.Forms.ProgressBar pgssBIntdLumE;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Timer Temporizador;
        private System.Windows.Forms.Label lblIntesidadLum;
        private System.Windows.Forms.Button btnGuardar;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.ComboBox RangoEncdLum;
        private System.Windows.Forms.ComboBox RangoApagTem;
        private System.Windows.Forms.ComboBox RangoEncdTem;
        private System.Windows.Forms.ComboBox RangoApagHum;
        private System.Windows.Forms.ComboBox RangoEncdHum;
        private System.Windows.Forms.ComboBox MinApagLum;
        private System.Windows.Forms.ComboBox MinEncdLum;
        private System.Windows.Forms.ComboBox HoraApagLum;
        private System.Windows.Forms.ComboBox HoraEncdLum;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.ComboBox MinApagTem;
        private System.Windows.Forms.ComboBox MinEncdTem;
        private System.Windows.Forms.ComboBox HoraApagTem;
        private System.Windows.Forms.ComboBox HoraEncdTem;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.ComboBox MinApagHum;
        private System.Windows.Forms.ComboBox MinEncdHum;
        private System.Windows.Forms.ComboBox HoraApagHum;
        private System.Windows.Forms.ComboBox HoraEncdHum;
        private System.Windows.Forms.Label lblSegundos;
        private System.Windows.Forms.Label lblDatosGuardados;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label lblConfigHora;
        private proyectoArduinoDataSet proyectoArduinoDataSet;
        private System.Windows.Forms.DataGridView dataGridView1;
    }
}

