﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;
using System.Threading;

namespace AplicaciónInvernadero
{
    public partial class Panel : Form
    {
        #region Variables
        // Crear SerialPort
        public static SerialPort spCOM;

        private string horaActual;
        bool IsClosed = false;
        bool inicializar = true;
        Thread Hilo;

        DataSet ds = new DataSet();

        // Temporizador
        //public static Timer temporizador = new Timer(1000);

        // Arreglos para almacenar datos de apagado y encendido
        private static string[] horarioTemperatura = new string[3];
        private static string[] horarioHumedad = new string[3];
        private static string[] horarioLuminosidad = new string[3];

        // Variables para guardar datos de temperatura y humedad
        private static int tempON;
        private static int tempOFF;
        private static int humON;
        private static int humOFF;
        private static int lumON;
        private static int lumOFF;

        // Indicar que un rango está activado
        private static bool rangoTemp = false;
        private static bool horarioTemp = false;
        private static bool rangoHum = false;
        private static bool horarioHum = false;
        private static bool rangoLum = false;
        private static bool horarioLum = false;

        // Instrucciones a enviar a Arduino
        private static string encenderBombilla = "BMON";
        private static string apagarBombilla = "BMOFF";
        private static string encenderVentilador = "VNON";
        private static string apagarVentilador = "VNOFF";
        private static string encenderRegadera = "RGON";
        private static string apagarRegadera = "RGOFF";
        
        // Instanciar Clase de acceso a base de datos
        Datos Historial = new Datos(); 
        #endregion

        public Panel()
        {
            InitializeComponent();
            lblFecha.Text = DateTime.Now.ToLongDateString();

            // Crear instancia del control SerialPort
            spCOM = new SerialPort();

          
            // Evitar modificar objetos desde subprocesos que no fueron creados 
            Control.CheckForIllegalCrossThreadCalls = false;

            ParametrosComboBox("Luminosidad");
            ParametrosComboBox("Humedad");
            ParametrosComboBox("Temperatura");
            HoraComboBox();
            MinutosComboBox();

            configurarPuerto();
            Temporizador.Start();

            if (inicializar)
            {
                btnOFFBombillo.Enabled = false;
                btnOFFVentilador.Enabled = false;
                btnOFFAgua.Enabled = false;
                lblDatosGuardados.Visible = false;
                inicializar = false;
            }
        }

        #region Llenar los ComboBox
        private void ParametrosComboBox(string parametro)
        {
            if (parametro == "Luminosidad")
            {
                for (int i = 0; i <= 100; i++)
                {
                   RangoEncdLum.Items.Add(i);
                }
            }
            else if(parametro == "Humedad")
            {
                for (int i = 0; i <= 100; i++)
                {

                    RangoEncdHum.Items.Add(i);
                    RangoApagHum.Items.Add(i);
                }
            }
            else if (parametro == "Temperatura")
            {
                for (int i = -20; i <= 50; i++)
                {
                    RangoEncdTem.Items.Add(i);
                    RangoApagTem.Items.Add(i);
                }
            }

            RangoEncdLum.SelectedIndex = 0;
            RangoEncdTem.SelectedItem = 0;
            RangoEncdHum.SelectedItem = 0;
            RangoApagTem.SelectedItem = 0;
            RangoApagHum.SelectedItem = 0;
        }

        private void HoraComboBox()
        {
            for(int j=0; j<24; j++)
            {
                if (j<10)
                {
                    string item = "0" + j.ToString();
                    HoraEncdLum.Items.Add(item);
                    HoraEncdTem.Items.Add(item);
                    HoraEncdHum.Items.Add(item);
                    HoraApagLum.Items.Add(item);
                    HoraApagTem.Items.Add(item);
                    HoraApagHum.Items.Add(item);
                }
                else
                {
                    HoraEncdLum.Items.Add(j);
                    HoraEncdTem.Items.Add(j);
                    HoraEncdHum.Items.Add(j);
                    HoraApagLum.Items.Add(j);
                    HoraApagTem.Items.Add(j);
                    HoraApagHum.Items.Add(j);
                }
            }

            HoraEncdLum.SelectedIndex = 0;
            HoraEncdTem.SelectedIndex = 0;
            HoraEncdHum.SelectedIndex = 0;
            HoraApagLum.SelectedIndex = 0;
            HoraApagTem.SelectedIndex = 0;
            HoraApagHum.SelectedIndex = 0;

            HoraEncdLum.SelectedIndex = 0;
            HoraEncdTem.SelectedIndex = 0;
            HoraEncdHum.SelectedIndex = 0;
            HoraApagLum.SelectedIndex = 0;
            HoraApagTem.SelectedIndex = 0;
            HoraApagHum.SelectedIndex = 0;
        }

        private void MinutosComboBox()
        {
            for (int j = 0; j < 60; j++)
            {
                if (j < 10)
                {
                    string item = "0" + j.ToString();
                    MinEncdLum.Items.Add(item);
                    MinEncdTem.Items.Add(item);
                    MinEncdHum.Items.Add(item);
                    MinApagLum.Items.Add(item);
                    MinApagTem.Items.Add(item);
                    MinApagHum.Items.Add(item);
                }
                else
                {
                    MinEncdLum.Items.Add(j);
                    MinEncdTem.Items.Add(j);
                    MinEncdHum.Items.Add(j);
                    MinApagLum.Items.Add(j);
                    MinApagTem.Items.Add(j);
                    MinApagHum.Items.Add(j);
                }
            }

            MinEncdLum.SelectedIndex = 0;
            MinEncdTem.SelectedIndex = 0;
            MinEncdHum.SelectedIndex = 0;
            MinApagLum.SelectedIndex = 0;
            MinApagTem.SelectedIndex = 0;
            MinApagHum.SelectedIndex = 0;

            MinEncdLum.SelectedIndex = 0;
            MinEncdTem.SelectedIndex = 0;
            MinEncdHum.SelectedIndex = 0;
            MinApagLum.SelectedIndex = 0;
            MinApagTem.SelectedIndex = 0;
            MinApagHum.SelectedIndex = 0;
        }
        #endregion

        #region Procesar Datos
        // Método para procesar lo recibido desde el puerto serial
        private void ProcesarDatos(string indata)
        {

            string[] datos = indata.Split(':');

            if (datos[0] == "Temperatura")
            {
                lblTemperatura.Text = datos[1];

                if (rangoTemp)
                {
                    if (tempON.ToString() == datos[1])
                    {
                        ptrBxTem.Image = Properties.Resources.wind_on;
                        spCOM.WriteLine(encenderVentilador);

                        Historial.registrar(lblTemperatura.Text, lblHumedad.Text, lblIntesidadLum.Text, "Ventilador", "Encendido por Rango");
                        ObtenerDatos();

                        btnONVentilador.Enabled = false;
                        btnOFFVentilador.Enabled = true;
                    }

                    if (tempOFF.ToString() == datos[1])
                    {
                        ptrBxTem.Image = Properties.Resources.wind_off;
                        spCOM.WriteLine(apagarVentilador);

                        Historial.registrar(lblTemperatura.Text, lblHumedad.Text, lblIntesidadLum.Text, "Ventilador", "Apagado por Rango");
                        ObtenerDatos();

                        btnONVentilador.Enabled = true;
                        btnOFFVentilador.Enabled = false;
                    }
                }
            }
            else if (datos[0] == "Humedad")
            {
                lblHumedad.Text = datos[1];

                if (rangoHum)
                {
                    if (humON.ToString() == datos[1])
                    {
                        ptrBxHum.Image = Properties.Resources.water_on;
                        spCOM.WriteLine(encenderRegadera);

                        Historial.registrar(lblTemperatura.Text, lblHumedad.Text, lblIntesidadLum.Text, "Rociadora", "Encendido por Rango");
                        ObtenerDatos();

                        btnONAgua.Enabled = false;
                        btnOFFAgua.Enabled = true;
                    }

                    if (humOFF.ToString() == datos[1])
                    {
                        ptrBxHum.Image = Properties.Resources.no_water;
                        spCOM.WriteLine(apagarRegadera);

                        Historial.registrar(lblTemperatura.Text, lblHumedad.Text, lblIntesidadLum.Text, "Rociadora", "Apagado por Rango");
                        ObtenerDatos();

                        btnONVentilador.Enabled = true;
                        btnOFFVentilador.Enabled = false;
                    }
                }
            }
            else if (datos[0] == "Luminosidad")
            {
                lblIntesidadLum.Text = datos[1];

                int valor = Convert.ToInt32(datos[1]);

                lblIntesidadLum.Text = valor.ToString() + "%";
                pgssBIntdLum.Value = valor;

                if (rangoLum)
                {
                    if (valor < lumON)
                    {
                        ptrBxIntdLum.Image = Properties.Resources.ON;
                        spCOM.WriteLine(encenderBombilla);

                        Historial.registrar(lblTemperatura.Text, lblHumedad.Text, lblIntesidadLum.Text, "Bombilla", "Encendido por Rango");
                        ObtenerDatos();

                        btnONBombillo.Enabled = false;
                        btnOFFBombillo.Enabled = true;
                    }
                    else
                    {
                        ptrBxIntdLum.Image = Properties.Resources.OFF;
                        spCOM.WriteLine(apagarBombilla);

                        Historial.registrar(lblTemperatura.Text, lblHumedad.Text, lblIntesidadLum.Text, "Bombilla", "Apagado por Rango");
                        ObtenerDatos();

                        btnONBombillo.Enabled = true;
                        btnOFFBombillo.Enabled = false;
                    }
                }
            }
        }
        #endregion

        #region Escuchar Puerto Serial
        private void EscuchaSerial()
        {
            while (!IsClosed)
            {
                try
                {
                    // Procesar lo leído por el puerto serial
                    string cadena = spCOM.ReadLine();
                    ProcesarDatos(cadena);
                }
                catch
                { }
            }
        }
        #endregion

        #region Configurar Puerto
        // Método para configurar el puerto serial
        private void configurarPuerto()
        {
            // Asigna el valor del nombre del puerto
            spCOM.PortName = "COM4";

            // Asigna el valor de la velocidad del puerto
            spCOM.BaudRate = 9600;

            // Crear una instancia con los parámetros correspondientes
            spCOM = new SerialPort(spCOM.PortName, spCOM.BaudRate);

            // Abrir puerto
            spCOM.Open();
        }
        #endregion

        #region Cerrar Aplicación
        private void Panel_FormClosing(object sender, FormClosingEventArgs e)
        {
            IsClosed = true;

            // Evaluar si el puerto serial está abierto
            if (spCOM.IsOpen)
            {
                // Si está abierto lo cierra para liberar los recursos
                spCOM.Close();
                Temporizador.Stop();    
            }

            Application.Exit();
        }
        #endregion

        #region Obtener Datos de la BBDD
        private void ObtenerDatos()
        {
            ds = Historial.obtenerDatos();
            dataGridView1.DataSource = ds.Tables[0];
        }
        #endregion

        #region Encender y apagar manualmente
        private void btnONBombillo_Click(object sender, EventArgs e)
        {
            ptrBxIntdLum.Image = Properties.Resources.ON;

            btnONBombillo.Enabled = false;
            btnOFFBombillo.Enabled = true;

            spCOM.WriteLine(encenderBombilla);

            Historial.registrar(lblTemperatura.Text, lblHumedad.Text, lblIntesidadLum.Text, "Bombilla", "Encendido por Usuario");
            ObtenerDatos();
        }

        private void btnOFFBombillo_Click(object sender, EventArgs e)
        {
            ptrBxIntdLum.Image = Properties.Resources.OFF;

            btnONBombillo.Enabled = true;
            btnOFFBombillo.Enabled = false;

            spCOM.WriteLine(apagarBombilla);

            Historial.registrar(lblTemperatura.Text, lblHumedad.Text, lblIntesidadLum.Text, "Bombilla", "Apagado por Usuario");
            ObtenerDatos();
        }

        private void btnONVentilador_Click(object sender, EventArgs e)
        {
            ptrBxTem.Image = Properties.Resources.wind_on;

            btnONVentilador.Enabled = false;
            btnOFFVentilador.Enabled = true;

            spCOM.WriteLine(encenderVentilador);

            Historial.registrar(lblTemperatura.Text, lblHumedad.Text, lblIntesidadLum.Text, "Ventilador", "Encendido por Usuario");
            ObtenerDatos();
        }
        
        private void btnOFFVentilador_Click(object sender, EventArgs e)
        {
            ptrBxTem.Image = Properties.Resources.wind_off;

            btnONVentilador.Enabled = true;
            btnOFFVentilador.Enabled = false;

            spCOM.WriteLine(apagarVentilador);

            Historial.registrar(lblTemperatura.Text, lblHumedad.Text, lblIntesidadLum.Text, "Ventilador", "Apagado por Usuario");
            ObtenerDatos();
        }
        
        private void btnONAgua_Click(object sender, EventArgs e)
        {
            ptrBxHum.Image = Properties.Resources.water_on;

            btnONAgua.Enabled = false;
            btnOFFAgua.Enabled = true;

            spCOM.WriteLine(encenderRegadera);

            Historial.registrar(lblTemperatura.Text, lblHumedad.Text, lblIntesidadLum.Text, "Rociadora", "Encendido por Usuario");
            ObtenerDatos();
        }
        
        private void btnOFFAgua_Click(object sender, EventArgs e)
        {
            ptrBxHum.Image = Properties.Resources.no_water;

            btnONAgua.Enabled = true;
            btnOFFAgua.Enabled = false;

            spCOM.WriteLine(apagarRegadera);

            Historial.registrar(lblTemperatura.Text, lblHumedad.Text, lblIntesidadLum.Text, "Rociadora", "Apagado por Usuario");
            ObtenerDatos();
        }
        #endregion

        #region temporizador
        private void timer1_Tick(object sender, EventArgs e)
        {
            horaActual = DateTime.Now.ToString("HH:mm");
            lblHora.Text = horaActual;
            lblSegundos.Text = DateTime.Now.ToString("ss");

            lblConfigHora.Text = DateTime.Now.ToString("HH:mm:ss");

            // En caso de coincidir la hora actual con la hora programada, realizar la acción correspondiente

            // Verificar que el encendido y apagado de la bombilla por horarios esté activado
            if (horarioLum)
            {
                if (horaActual == horarioLuminosidad[1])
                {
                    ptrBxIntdLum.Image = Properties.Resources.ON;
                    spCOM.WriteLine(encenderBombilla);

                    Historial.registrar(lblTemperatura.Text, lblHumedad.Text, lblIntesidadLum.Text, "Bombilla", "Encendido por Horario");
                    ObtenerDatos();

                    btnONBombillo.Enabled = false;
                    btnOFFBombillo.Enabled = true;
                }

                if (horaActual == horarioLuminosidad[2])
                {
                    ptrBxIntdLum.Image = Properties.Resources.OFF;
                    spCOM.WriteLine(apagarBombilla);

                    Historial.registrar(lblTemperatura.Text, lblHumedad.Text, lblIntesidadLum.Text, "Bombilla", "Apagado por Horario");
                    ObtenerDatos();

                    btnONBombillo.Enabled = true;
                    btnOFFBombillo.Enabled = false;
                }
            }

            // Verificar que el encendido y apagado del ventilador por horarios esté activado
            if (horarioTemp)
            {
                if (horaActual == horarioTemperatura[1])
                {
                    ptrBxTem.Image = Properties.Resources.wind_on;
                    spCOM.WriteLine(encenderVentilador);

                    Historial.registrar(lblTemperatura.Text, lblHumedad.Text, lblIntesidadLum.Text, "Ventilador", "Encendido por Horario");
                    ObtenerDatos();

                    btnONVentilador.Enabled = false;
                    btnOFFVentilador.Enabled = true;
                }

                if (horaActual == horarioTemperatura[2])
                {
                    ptrBxTem.Image = Properties.Resources.wind_off;
                    spCOM.WriteLine(apagarVentilador);

                    Historial.registrar(lblTemperatura.Text, lblHumedad.Text, lblIntesidadLum.Text, "Ventilador", "Apagado por Horario");
                    ObtenerDatos();

                    btnONVentilador.Enabled = true;
                    btnOFFVentilador.Enabled = false;
                }
            }

            // Verificar que el encendido y apagado de la regadera por horarios esté activado
            if (horarioHum)
            {
                if (horaActual == horarioHumedad[1])
                {
                    ptrBxHum.Image = Properties.Resources.water_on;
                    spCOM.WriteLine(encenderRegadera);

                    Historial.registrar(lblTemperatura.Text, lblHumedad.Text, lblIntesidadLum.Text, "Rociadora", "Encendido por Horario");
                    ObtenerDatos();

                    btnONAgua.Enabled = false;
                    btnOFFAgua.Enabled = true;
                }

                if (horaActual == horarioHumedad[2])
                {
                    ptrBxHum.Image = Properties.Resources.no_water;
                    spCOM.WriteLine(apagarRegadera);

                    Historial.registrar(lblTemperatura.Text, lblHumedad.Text, lblIntesidadLum.Text, "Rociadora", "Apagado por Horario");
                    ObtenerDatos();

                    btnONAgua.Enabled = true;
                    btnOFFAgua.Enabled = false;
                }
            }
        }
        #endregion

        private void Panel_Load(object sender, EventArgs e)
        {
            Hilo = new Thread(EscuchaSerial);
            Hilo.Start();
        }

        private void Panel_FormClosed(object sender, FormClosedEventArgs e)
        {
            IsClosed = true;
            if (spCOM.IsOpen)
                spCOM.Close();
        }

        private void chBxRB_CheckedChanged(object sender, EventArgs e)
        {
            lumON = Convert.ToInt32(RangoEncdLum.Text);

            if (chBxRB.Checked)
            {
                rangoLum = true;
            }
            else
            {
                rangoLum = false;
            }
        }

        private void chBxRV_CheckedChanged(object sender, EventArgs e)
        {
            tempON = Convert.ToInt32(RangoEncdTem.Text);
            tempOFF = Convert.ToInt32(RangoApagTem.Text);
            
            if(chBxRV.Checked)
            {
                rangoTemp = true;
            }
            else
            {
                rangoTemp = false;
            }
        }

        private void chBxRR_CheckedChanged(object sender, EventArgs e)
        {
            humON = Convert.ToInt32(RangoEncdHum.Text);
            humOFF = Convert.ToInt32(RangoApagTem.Text);
            
            if(chBxRR.Checked)
            {
                rangoHum = true;
            }
            else
            {
                rangoHum = false;
            }
        }
        
        private void chBxHB_CheckedChanged(object sender, EventArgs e)
        {
            horarioLuminosidad[0] = "Habilitado";
            horarioLuminosidad[1] = HoraEncdLum.Text + ":" + MinEncdLum.Text;
            horarioLuminosidad[2] = HoraApagLum.Text + ":" + MinApagLum.Text;
            
            if(chBxHB.Checked)
            {
                horarioLum = true;
            }
            else
            {
                horarioLum = false;
            }
        }

        private void chBxHV_CheckedChanged(object sender, EventArgs e)
        {
            horarioTemperatura[0] = "Habilitado";
            horarioTemperatura[1] = HoraEncdTem.Text + ":" + MinEncdTem.Text;
            horarioTemperatura[2] = HoraApagTem.Text + ":" + MinApagTem.Text;
            
            if(chBxHV.Checked)
            {
                horarioTemp = true;
            }
            else
            {
                horarioTemp = false;
            }
        }

        private void chBxHR_CheckedChanged(object sender, EventArgs e)
        {
            horarioHumedad[0] = "Habilitado";
            horarioHumedad[1] = HoraEncdHum.Text + ":" + MinEncdHum.Text;
            horarioHumedad[2] = HoraApagHum.Text + ":" + MinApagHum.Text;
            
            if(chBxHR.Checked)
            {
                horarioHum = true;
            }
            else
            {
                horarioHum = false;
            }
        }
        
        private void btnGuardar_Click(object sender, EventArgs e)
        {
            //Asignar datos de luminosidad por rango
            if(rangoLum)
            {
                pgssBIntdLumE.Value = lumON;
                pgssBIntdLumA.Value = lumOFF;

                grpBxRangoLum.Enabled = true;
            }
            else
            {
                grpBxRangoLum.Enabled = false;
            }

            //Asignar datos de luminosidad por horas
            if (horarioLum)
            {
                txtbxHL_ON.Text = HoraEncdLum.Text + ":" + MinEncdLum.Text;
                txtbxHL_OFF.Text = HoraApagLum.Text + ":" + MinApagLum.Text;

                grpBxHorLum.Enabled = true;
            }
            else
            {
                grpBxHorLum.Enabled = false;
            }

            //Asignar datos de temperatura por rango
            if (rangoTemp)
            {
                txtbxRT_ON.Text = tempON.ToString();
                txtbxRT_OFF.Text = tempOFF.ToString();

                grpBxRangoTem.Enabled = true;
            }
            else
            {
                grpBxRangoTem.Enabled = false;
            }

            //Asignar datos de temperatura por horas
            if (horarioTemp)
            {
                txtbxHT_ON.Text = HoraEncdTem.Text + ":" + MinEncdTem.Text;
                txtbxHT_OFF.Text = HoraApagTem.Text + ":" + MinApagTem.Text;

                grpBxHorTem.Enabled = true;
            }
            else
            {
                grpBxHorTem.Enabled = false;
            }

            //Asignar datos de humedad por rango
            if (rangoHum)
            {
                txtbxRH_ON.Text = humON.ToString();
                txtbxRH_OFF.Text = humOFF.ToString();

                grpBxRangoHum.Enabled = true;
            }
            else
            {
                grpBxRangoHum.Enabled = false;
            }

            //Asignar datos de humedad por horas
            if (horarioHum)
            {
                txtbxHH_ON.Text = HoraEncdHum.Text + ":" + MinEncdHum.Text;
                txtbxHH_OFF.Text = HoraApagHum.Text + ":" + MinApagHum.Text;

                grpBxHorHum.Enabled = true;
            }
            else
            {
                grpBxHorHum.Enabled = false;
            }

            MessageBox.Show("Cambios efectuados");
        }
    }
}