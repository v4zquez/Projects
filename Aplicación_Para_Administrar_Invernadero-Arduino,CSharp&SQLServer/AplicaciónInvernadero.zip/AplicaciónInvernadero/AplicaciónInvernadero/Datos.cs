﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace AplicaciónInvernadero
{
    public class Datos
    {
        private SqlConnection cnn;
        private SqlCommand comando;
        private SqlDataAdapter adaptador;

        public Datos()
        {
            this.cnn = new SqlConnection(ConfigurationManager.AppSettings["conx"]);
        }

        public void registrar(string temperatura, string humedad, string luminosidad, string dispositivo, string accion)
        {
            cnn.Open();
            comando = new SqlCommand("registrarSP", cnn);
            comando.CommandType = CommandType.StoredProcedure;
            comando.Parameters.AddWithValue("@temp", temperatura);
            comando.Parameters.AddWithValue("@hum", humedad);
            comando.Parameters.AddWithValue("@lum", luminosidad);
            comando.Parameters.AddWithValue("@disp", dispositivo);
            comando.Parameters.AddWithValue("@acc", accion);
            comando.ExecuteNonQuery();
            cnn.Close();
        }

        public DataSet obtenerDatos()
        {
            cnn.Open();
            comando = new SqlCommand("select temperatura_Centigrados, porcentaje_humedad, porcentaje_luminosidad, dispositivo, accion, fecha  from historial", cnn);
            adaptador = new SqlDataAdapter(comando);
            comando.CommandType = CommandType.Text;
            comando.ExecuteNonQuery();
            DataSet ds = new DataSet();
            adaptador.Fill(ds);
            cnn.Close();
            return (ds);
        }
    }
}
