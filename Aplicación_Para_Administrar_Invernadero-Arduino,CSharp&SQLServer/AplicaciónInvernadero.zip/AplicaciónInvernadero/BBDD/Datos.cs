﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace BBDD
{
    public class Datos
    {
        private SqlConnection cnn;
        private string connetionString;
        private SqlCommand comando;

        private SqlConnection conexion()
        {
            connetionString = @"Data Source=DESKTOP-MUA4AI2; Initial Catalog=proyectoArduino; User ID=sa; Password=progra";
            cnn = new SqlConnection(connetionString);
            cnn.Open();
            
            return cnn;
        }

        public bool registar(string temperatura, string humedad, string luminosidad, string dispositivo, string estado)
        {
            using (conexion())
            {
                comando = new SqlCommand("Insertar_Cliente", cnn);
                comando.CommandType = CommandType.StoredProcedure;
                comando.Parameters.AddWithValue("@temp", temperatura);
                comando.Parameters.AddWithValue("@hum", humedad);
                comando.Parameters.AddWithValue("@lum", luminosidad);
                comando.Parameters.AddWithValue("@disp", dispositivo);
                comando.Parameters.AddWithValue("@est", estado);
                comando.ExecuteNonQuery();
                cnn.Close();
                return true;
            }
        }
    }
}
